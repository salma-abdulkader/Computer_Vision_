# -*- coding: utf-8 -*-
"""
Created on Sat Nov 30 17:57:34 2024

@author: DELL
"""

import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
import cv2
import numpy as np
from ultralytics import YOLO
from ultralytics.utils.plotting import Annotator, colors

model = YOLO(r'C:\Users\mshah\Downloads\best.pt') 


image_path = r'C:\Users\mshah\Downloads\Rice-Leaf-Disease.v6i.yolov8\valid\images\bacterial_leaf_blight4_jpg.rf.e1c596253ea4cb774245c07daef74feb.jpg'  
im0 = cv2.imread(image_path)

if im0 is None:
    print("Image not exist")
else:

    annotator = Annotator(im0, line_width=2)


    results = model(im0)

  
    if results[0].masks is not None:
        masks = results[0].masks.xy
        for mask in masks:
            cv2.polylines(im0, [np.int32([mask])], isClosed=True, color=(255, 0, 0), thickness=2)

   
    cv2.imshow("Image Segmentation", im0)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
